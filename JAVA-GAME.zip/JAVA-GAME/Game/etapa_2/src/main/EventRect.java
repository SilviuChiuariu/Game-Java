package main;

import java.awt.*;

//NE OFERA POSIBILITATEA SA CREEM UN EVENT CE SE PETRECE DOAR ODATA!!!
public class EventRect extends Rectangle {
    int eventRectDefaultX ,eventRectDefaultY;
    boolean eventDone =false;
}
