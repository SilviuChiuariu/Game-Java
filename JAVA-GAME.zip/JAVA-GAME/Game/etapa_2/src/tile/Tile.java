package tile;

import java.awt.image.BufferedImage;

public class Tile {         //creem obiectul tile
    public BufferedImage image;
    public boolean colision=false;
}
